import Nested1 from "./components/Nested1"; // Props version
import WithContext1 from "./components/WithContext1"; // Context version

function App() {
  return (
    <div>
      <h2>Using Props to Pass Data</h2>
      <Nested1 />

      <h2>Using Context API</h2>
      <WithContext1 />
    </div>
  );
}

export default App;
