import React, { useContext } from "react";
import WithContext3 from "./WithContext3";
import NameContext from "../context/NameContext";

export default function WithContext2() {
  const name = useContext(NameContext); // Get value from context

  return (
    <>
      <h1>Hello {name}!</h1>
      <WithContext3 />
    </>
  );
}
