import React, { useContext } from "react";
import NameContext from "../context/NameContext";

export default function WithContext3() {
  const name = useContext(NameContext); // Get value from context

  return <p>Welcome {name} to the site!</p>;
}
