import React from "react";

export default function Nested3({ name }) {
  return <p>Welcome {name} to the site!</p>;
}
