import React from "react";
import Nested3 from "./Nested3";

export default function Nested2({ name }) {
  return (
    <>
      <h1>Hello {name}!</h1>
      <Nested3 name={name} />
    </>
  );
}
