import React, { useState } from "react";
import WithContext2 from "./WithContext2";
import NameContext from "../context/NameContext";

export default function WithContext1() {
  const [name, setName] = useState("No name");

  return (
    <div>
      <input 
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Enter your name"
      />
      {/* Provide the context value */}
      <NameContext.Provider value={name}>
        <WithContext2 />
      </NameContext.Provider>
    </div>
  );
}
