import { createContext } from "react";

// Create a context with a default value
const NameContext = createContext("No name");

export default NameContext;
