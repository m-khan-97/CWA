import { response } from "express";
import {useState} from "react";

function App(){
    const [songs, setSongs] = useState([]); //State for storing song data
    const [searchArtist, setSearchArtist] = useState(""); //State for artist search input
    const [darkMode, setDarkMode] = useState(false);
}

const searchByArtist = () => {
    fetch(`/artist/${searchArtist}`)
    .then(response => response.json())
    .then(data => setSongs(data)) //Update the state with searched songs
    .catch(error => console.error('Error fetching songs by artist:', error));

};

return(
    <div>
    <input 
    type="text"
    value={searchArtist}
    onChange={(e) => setSearchArtist(e.target.value)}
    placeholder="Search by Artist"
    />
    <button onClick={searchByArtist}>Search</button>
    </div>
)