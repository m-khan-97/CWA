export default function Search ({searchArtist, setSearchArtist, searchByArtist}){

    return(
        <div>
      {/* Input for searching by artist */}
      <input
        type="text"
        value={searchArtist}
        onChange={(e) => {
          setSearchArtist(e.target.value) // Update artist search input
          searchByArtist(e.target.value)}}  
        placeholder="Search by artist"
      />
      {/* <button onClick={searchByArtist}>Search</button> */}
      </div>
    );
}