import { useState } from "react";

export default function AddSong({ userRole }) {
  const [title, setTitle] = useState("");
  const [artist, setArtist] = useState("");
  const [year, setYear] = useState("");
  const [message, setMessage] = useState("");

  const handleAddSong = async () => {
    if (!title || !artist || !year) {
      alert("All fields are required");
      return;
    }

    try {
      const response = await fetch("/songs/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, artist, year }),
      });

      const data = await response.json();
      setMessage(data.message);
    } catch (error) {
      console.error("Error adding song:", error);
    }
  };

  if (userRole !== "admin") return null; // Show only if logged in as admin

  return (
    <div>
      <h3>Add a Song</h3>
      <input type="text" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input type="text" placeholder="Artist" value={artist} onChange={(e) => setArtist(e.target.value)} />
      <input type="text" placeholder="Year" value={year} onChange={(e) => setYear(e.target.value)} />
      <button onClick={handleAddSong}>Go!</button>
      {message && <p>{message}</p>}
    </div>
  );
}
