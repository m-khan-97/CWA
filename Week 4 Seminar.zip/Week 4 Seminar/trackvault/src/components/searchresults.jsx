export default function SearchResults({songs}){

    return(
        <ul>
        {songs.map((song) => (
          <li key={song.id}>
            {song.title} by {song.artist}, Year: {song.year}, Quantity: {song.quantity}
          </li>
        ))}
      </ul>
    );
}