import express from 'express';
import db from './database.js';
import ViteExpress from 'vite-express';

const app = express();
app.use(express.json()); // Middleware to parse JSON request bodies

// Mock users for login authentication
const users = {
  admin: { password: "admin123", role: "admin" },
  user: { password: "user123", role: "user" }
};

// Route for user login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (users[username] && users[username].password === password) {
    res.json({ success: true, role: users[username].role });
  } else {
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

// Route to fetch all songs
app.get('/songs/all', (req, res) => {
  try {
    const allSongs = db.prepare('SELECT * FROM wadsongs').all();
    res.json(allSongs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to search for songs by artist
app.get('/artist/:artist', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist=?');
    const results = stmt.all(req.params.artist);
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to add a new song (Only Admin)
app.post('/songs/add', (req, res) => {
  try {
    const { title, artist, year } = req.body;
    const stmt = db.prepare('INSERT INTO wadsongs (title, artist, year, quantity) VALUES (?, ?, ?, ?)');
    stmt.run(title, artist, year, 10); // Default quantity 10
    res.json({ success: true, message: "Song added successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

ViteExpress.listen(app, 3000, () => {
  console.log('Server with Vite middleware running on port 3000.');
});
