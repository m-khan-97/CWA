import React from 'react';
import ReactDOM from 'react-dom/client';
import Counter from './counter';

ReactDOM.createRoot(document.getElementById('root')).render(

    <Counter />
  
);
