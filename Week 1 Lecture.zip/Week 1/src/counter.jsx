import React, { useState } from 'react';

function Counter() {
    const [count, setCount] = useState(0);

    function incrementCounter() {
        setCount(count + 1);
    }

    function resetCounter() {
        setCount(0);
    }

    return (
        <div>
            <p>You have clicked the counter {count} times.</p>
            <button onClick={incrementCounter}>Increment Counter</button>
            <button onClick={resetCounter}>Reset Counter</button>
        </div>
    );
}

export default Counter;
