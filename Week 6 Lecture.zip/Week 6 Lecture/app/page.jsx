export default function Page() {
    return (
        <div>
    <h1>Welcome to TrackVault!</h1>

    </div>
    );
}