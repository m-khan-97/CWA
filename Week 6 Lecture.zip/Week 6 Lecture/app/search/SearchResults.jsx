import Database from 'better-sqlite3';

export default function SearchResults({ artist }) {
  const db = new Database('wadsongs.db');

  const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist = ?');
  const results = stmt.all(artist);

  const songs = results.map(song => (
    <li key={song.id}>
      {song.title} by {song.artist} ({song.year})
    </li>
  ));

  return <ul>{songs}</ul>;
}
