import SearchForm from "./SearchForm.jsx";
import SearchResults from "./SearchResults.jsx";

export default function Page ({ searchParams }) {
  return (
    <div>
      <h2>Searching for : {searchParams.artist}</h2>
      <SearchForm />
      <SearchResults artist={searchParams.artist} />
    </div>
  );
}
  