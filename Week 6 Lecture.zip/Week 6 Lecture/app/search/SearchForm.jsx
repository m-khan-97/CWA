'use client';

import { useSearchParams, usePathname, useRouter } from 'next/navigation';

export default function SearchForm() {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const { replace } = useRouter();

  const handleSearch = () => {
    const artist = document.getElementById('artist').value;
    const params = new URLSearchParams(searchParams);
    params.set('artist', artist);
    replace(`${pathname}?${params.toString()}`);
  };

  return (
    <div>
      <label>Search by Artist:</label><br />
      <input id="artist" placeholder="e.g. Oasis" />
      <button onClick={handleSearch}>Search</button>
    </div>
  );
}
