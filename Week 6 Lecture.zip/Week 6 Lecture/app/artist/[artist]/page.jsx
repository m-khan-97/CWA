import LeafletMap from '/app/components/LeafletMap.jsx';
import Database from 'better-sqlite3';

export default function Page({ params }) {
  const db = new Database('wadsongs.db');
  const stmt = db.prepare('SELECT * FROM artists WHERE name = ?');
  const artistData = stmt.get(params.artist);

  if (!artistData) {
    return <p>Artist not found.</p>;
  }

  return (
    <div>
      <h2>{artistData.name}</h2>
      <p>Hometown: {artistData.hometown}</p>
      <LeafletMap lat={artistData.lat} lon={artistData.lon} />
    </div>
  );
}
