export default function Page() {
    return(
        <div>
        <h2>About HitTastic!</h2>
        <p>HitTastic! is the top site for music. Whether it's rock, pop, indie, rap or pure liquid cheese you're into, you're sure to find it here.</p>
        </div>
    );
}