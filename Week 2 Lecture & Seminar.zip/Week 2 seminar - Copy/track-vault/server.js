import express from 'express';
import ViteExpress from 'vite-express';
import db from './database.js';

const app = express();

//Fetch All Songs
app.get('/songs/all', (req,res) => {
    try{
    const allsongs = db.prepare('SELECT * FROM wadsongs'). all();
    res.json(allsongs);
    }
    catch(error){
        res.status(500).json({error: error.message});
    }
});

//Route to fetch songs by artist
app.get('songs/artist/:artist', (req,res) => {
    // const {artist} = req.params;
    const artistSongs= db.prepare('SELECT * FROM wadsongs WHERE artist = ?' ).all();
    res.json();
});



ViteExpress.listen(app, 3000,() => {
    console.log('Server running on port 3000.');
});