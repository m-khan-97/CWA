import React from "react";

function Greeting(){
    return <h1>Hello from the Greeting Component</h1>;
}

export default Greeting

