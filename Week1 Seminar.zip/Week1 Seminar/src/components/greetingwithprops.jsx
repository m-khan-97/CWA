import React from "react";

function Greetings(props){
return <p style={{backgroundColor: 'yellow', color: 'blue'}}>Hello {props.firstname} {props.lastname} from the React</p>;
}
export default Greetings