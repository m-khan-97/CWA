import React from "react";
import ReactDOM from 'react-dom/client';
import Greetings from "./components/greetingwithprops";


const root = ReactDOM.createRoot(document.getElementById('root')).render(<Greetings firstname = "John" lastname = "Doe" />);


