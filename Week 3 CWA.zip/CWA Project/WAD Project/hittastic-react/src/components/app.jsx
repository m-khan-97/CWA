import { useState, useEffect } from 'react';
import Search from './search';
import SearchResults from './searchresult';

function App() {
  const [songs, setSongs] = useState([]);          // State for storing song data
  const [darkMode, setDarkMode] = useState(false);  // State for light/dark mode

  // Fetch all songs from the API when the app loads
  useEffect(() => {
    fetch('/songs/all')
      .then(response => response.json())
      .then(data => setSongs(data))  // Store songs in state
      .catch(error => console.error('Error fetching all songs:', error));
  }, []);

  // Fetch songs by artist
  const searchByArtist = (artist) => {
    fetch(`/artist/${artist}`)
      .then(response => response.json())
      .then(data => setSongs(data))  // Update state with searched songs
      .catch(error => console.error('Error fetching songs by artist:', error));
  };

  // Toggle between light and dark mode
  const toggleDarkMode = () => setDarkMode(!darkMode);

  return (
    <div className={darkMode ? 'dark-mode' : 'light-mode'}>
      <h1>TrackVault!</h1>

      {/* Button to toggle dark/light mode */}
      <button onClick={toggleDarkMode}>
        {darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      </button>

      {/* Search component */}
      <Search onSearch={searchByArtist} />

      {/* SearchResults component */}
      <SearchResults songs={songs} />
    </div>
  );
}

export default App;
