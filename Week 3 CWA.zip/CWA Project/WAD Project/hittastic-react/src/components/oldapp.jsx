import { useState, useEffect } from 'react';

function App() {
  const [songs, setSongs] = useState([]);
  const [searchArtist, setSearchArtist] = useState("");

  // Fetch all songs from the API when the app loads
  useEffect(() => {
    fetch('/songs/all')
      .then(response => response.json())
      .then(data => setSongs(data))
      .catch(error => console.error('Error fetching all songs:', error));
  }, []);

  // Fetch songs by artist
  const searchByArtist = () => {
    fetch(`/artist/${searchArtist}`)
      .then(response => response.json())
      .then(data => setSongs(data))
      .catch(error => console.error('Error fetching songs by artist:', error));
  };

  return (
    <div>
      <h1>TrackVault!</h1>

      {/* Search by artist */}
      <input
        type="text"
        value={searchArtist}
        onChange={(e) => setSearchArtist(e.target.value)}
        placeholder="Search by artist"
      />
      <button onClick={searchByArtist}>Search</button>

      {/* Display list of songs */}
      <ul>
        {songs.map((song) => (
          <li key={song.id}>
            {song.title} by {song.artist}, Year: {song.year}, Price: ${song.price}, Quantity: {song.quantity}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
