import React from 'react';

function SearchResults({ songs }) {
  return (
    <ul>
      {songs.map((song) => (
        <li key={song.id}>
          {song.title} by {song.artist}, Year: {song.year}, Price: ${song.price}, Quantity: {song.quantity}
        </li>
      ))}
    </ul>
  );
}

export default SearchResults;
