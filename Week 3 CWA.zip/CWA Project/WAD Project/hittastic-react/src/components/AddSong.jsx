import { useState } from 'react';

function AddSong() {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [year, setYear] = useState('');

  const addSong = () => {
    const newSong = { title, artist, year };
    // Here you'd send the new song to the server
    console.log('Song added:', newSong);
    alert('Song added successfully!');
  };

  return (
    <div>
      <h3>Add a song:</h3>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
      />
      <input
        type="text"
        value={artist}
        onChange={(e) => setArtist(e.target.value)}
        placeholder="Artist"
      />
      <input
        type="text"
        value={year}
        onChange={(e) => setYear(e.target.value)}
        placeholder="Year"
      />
      <button onClick={addSong}>Add Song</button>
    </div>
  );
}

export default AddSong;
