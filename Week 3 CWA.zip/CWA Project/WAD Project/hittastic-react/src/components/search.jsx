import React, { useState } from 'react';

function Search({ onSearch }) {
  const [searchArtist, setSearchArtist] = useState(""); // Local state for artist search input

  const handleSearch = () => {
    onSearch(searchArtist);  // Call the function passed down as a prop from App
  };

  return (
    <div>
      <input
        type="text"
        value={searchArtist}
        onChange={(e) => setSearchArtist(e.target.value)} // Update local search input state
        placeholder="Search by artist"
      />
      <button onClick={handleSearch}>Search</button>
    </div>
  );
}

export default Search;
