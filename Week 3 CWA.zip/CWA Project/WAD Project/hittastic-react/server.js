import express from 'express';
import Database from 'better-sqlite3';
import ViteExpress from 'vite-express';

// Create the Express server
const app = express();

// Enable reading JSON from the request body of POST requests
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Load the database
const db = new Database('wadsongs.db');

// Route to fetch all songs
app.get('/songs/all', (req, res) => {
  try {
    const allSongs = db.prepare('SELECT * FROM wadsongs').all();
    res.json(allSongs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to search by artist
app.get('/artist/:artist', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist = ?');
    const results = stmt.all(req.params.artist);
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Use Vite as middleware for hot-reloading during development
ViteExpress.listen(app, 3000, () => {
  console.log('Server with Vite middleware running on port 3000.');
});
