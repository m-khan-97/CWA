import Database from 'better-sqlite3';

// Connect to the SQLite database
const db = new Database('./wadsongs.db'); // Ensure wadsongs.db is placed in the root directory

// Export the db object to use in your Express routes
export default db;
