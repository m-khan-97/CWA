import { useState, createContext } from "react";

const DarkModeContext = createContext();

export function DarkModeToggle({children}) {
    const [darkMode, setDarkMode] = useState(false);

    const toggleDarkMode = () => {
        setDarkMode((prevMode) => !prevMode);
    };

    return(
        <DarkModeContext.Provider value= {{darkMode, toggleDarkMode}}>
        {children}
        </DarkModeContext.Provider>
    )
}