import { useState, useEffect } from "react";
import Search from "./search";
import SearchResults from "./searchresults";
import Login from "./login";
import AddSong from "./addsong";

function App() {
  const [songs, setSongs] = useState([]); 
  const [searchArtist, setSearchArtist] = useState(""); 
  const [userRole, setUserRole] = useState(null);

  // Fetch songs by artist
  const searchByArtist = (artist) => {
    fetch(`/artist/${artist}`)
      .then(response => response.json())
      .then(data => setSongs(data))
      .catch(error => console.error("Error fetching songs by artist:", error));
  };

  // Fetch all songs on load
  useEffect(() => {
    fetch("/songs/all")
      .then(response => response.json())
      .then(data => setSongs(data))
      .catch(error => console.error("Error fetching all songs:", error));
  }, []);

  return (
    <div>
      {userRole ? <p>Logged in as {userRole}</p> : <Login setUserRole={setUserRole} />}
      <Search searchArtist={searchArtist} setSearchArtist={setSearchArtist} searchByArtist={searchByArtist} />
      <SearchResults songs={songs} />
      <AddSong userRole={userRole} />
    </div>
  );
}

export default App;
