import express from 'express';
import db from './database.js';
import ViteExpress from 'vite-express'; // Import vite-express for development

// Create our Express server.
const app = express();

// Route to fetch all songs
app.get('/songs/all', (req, res) => {
  try {
    const allSongs = db.prepare('SELECT * FROM wadsongs').all();
    res.json(allSongs);  // Return all songs as JSON
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to search for songs by artist
app.get('/artist/:artist', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM wadsongs WHERE artist=?');
    const results = stmt.all(req.params.artist);
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Use Vite as middleware for Hot Module Reloading (HMR)
ViteExpress.listen(app, 3000, () => {
  console.log('Server with Vite middleware running on port 3000.');
});
