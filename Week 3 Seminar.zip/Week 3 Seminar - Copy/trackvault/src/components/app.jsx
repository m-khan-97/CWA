import { useState, useEffect } from 'react';
import Search from './search';
import SearchResults from './searchresults';

function App() {
  const [songs, setSongs] = useState([]);          // State for storing song data
  const [searchArtist, setSearchArtist] = useState("");  // State for artist search input
  const [darkMode, setDarkMode] = useState(false);  // State for light/dark mode

  // Fetch songs by artist
  const searchByArtist = () => {
    fetch(`/artist/${searchArtist}`)
      .then(response => response.json())
      .then(data => setSongs(data))  // Update state with searched songs
      .catch(error => console.error('Error fetching songs by artist:', error));
  };

   // Fetch all songs from the API when the app loads
  useEffect(() => {
    fetch('/songs/all')
      .then(response => response.json())
      .then(data => setSongs(data))  // Store songs in state
      .catch(error => console.error('Error fetching all songs:', error));
  }, []);

  return (
    
    <div>
      <Search 
      searchArtist={searchArtist}
      setSearchArtist={setSearchArtist}
      searchByArtist={searchByArtist}></Search>

      <SearchResults
      songs={songs}></SearchResults>

      </div>
  )
}

export default App;
